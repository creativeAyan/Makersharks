<?php
$email=$_POST['email'];
$firstName=$_POST['firstName'];
$lastName=$_POST['lastName'];

$to = "desktopayan@gmail.com";
$subject = "Send Form data as CSV attachment and send email ";

$message = "".
"Email: $email" . "\n" .
"First Name: $firstName" . "\n" .
"Last Name: $lastName";