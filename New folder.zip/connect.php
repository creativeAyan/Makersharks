<?php
ini_set( 'display_errors', 1 );
error_reporting( E_ALL );
$from = "test@hostinger-tutorials.com";
$to = "desktopayan@gmail.com";
$subject = "ayan leads";
$message = "Details:
            Name-".$_POST["firstname"]."
            Lname-".$_POST["Lastname"]."
            NUmber-".$_POST["phone"]."
            
            Payment Mode-".$_POST['paymentMode']."
            Address-".$_POST['address']."
            Pincode-".$_POST['pincode'];
$headers = "From:" . $from;
if(mail($to,$subject,$message, $headers)) {
echo "The email message was sent.";
} else {
echo "The email message was not sent.";
}
header("location: http://ashlartattva.ashlarspaces.com/Thank_You/index.html");
?>